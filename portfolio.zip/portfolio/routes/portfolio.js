const express = require("express");
const PortfolioItem = require("../models/PortfolioItem"); // Импорт модели
const mongoose = require("mongoose"); // Для проверки валидности ObjectId
const router = express.Router();
const { Authenticate, Authorize } = require("../middleware/Auth");

// Вспомогательная функция для проверки валидности ObjectId
const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

// Создание элемента (защищен аутентификацией и авторизацией)
router.post("/", Authenticate, Authorize(["admin", "editor"]), async (req, res) => {
  const { title, description, images } = req.body;

  // Валидация данных
  if (!title || !description || !images || images.length === 0) {
    return res.status(400).send("Title, description, and at least one image are required");
  }

  try {
    const newItem = new PortfolioItem({ title, description, images });
    await newItem.save();
    res.status(201).send(newItem);
  } catch (err) {
    res.status(500).send("Error creating portfolio item: " + err.message);
  }
});

// Получение всех элементов (доступно всем пользователям)
router.get("/", async (req, res) => {
  try {
    const items = await PortfolioItem.find();
    res.status(200).send(items);
  } catch (err) {
    res.status(500).send("Error fetching portfolio items: " + err.message);
  }
});

// Обновление элемента (защищен аутентификацией и авторизацией)
router.put("/:id", Authenticate, Authorize(["admin", "editor"]), async (req, res) => {
  const { id } = req.params;

  // Проверка валидности ID
  if (!isValidObjectId(id)) {
    return res.status(400).send("Invalid portfolio item ID");
  }

  try {
    const updatedItem = await PortfolioItem.findByIdAndUpdate(id, req.body, { new: true });
    if (!updatedItem) {
      return res.status(404).send("Portfolio item not found");
    }
    res.status(200).send(updatedItem);
  } catch (err) {
    res.status(500).send("Error updating portfolio item: " + err.message);
  }
});

// Удаление элемента (защищен аутентификацией и авторизацией)
router.delete("/:id", Authenticate, Authorize(["admin", "editor"]), async (req, res) => {
  const { id } = req.params;

  // Проверка валидности ID
  if (!isValidObjectId(id)) {
    return res.status(400).send("Invalid portfolio item ID");
  }

  try {
    const deletedItem = await PortfolioItem.findByIdAndDelete(id);
    if (!deletedItem) {
      return res.status(404).send("Portfolio item not found");
    }
    res.status(200).send("Item deleted");
  } catch (err) {
    res.status(500).send("Error deleting portfolio item: " + err.message);
  }
});

module.exports = router;
