const express = require("express");
const speakeasy = require("speakeasy");
const qrcode = require("qrcode");
const bcrypt = require("bcrypt");
const User = require("../models/User");
const router = express.Router();
const { Authenticate, Authorize } = require("../middleware/Auth");


// Регистрация нового пользователя
router.post("/register", async (req, res) => {
  const { username, password, firstName, lastName, age, gender } = req.body;

  // Проверка на обязательность полей
  if (!username || !password || !firstName || !lastName || !age || !gender) {
    return res.status(400).send("All fields are required");
  }

  try {
    // Хеширование пароля перед сохранением
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      username,
      password: hashedPassword, // Сохраняем хешированный пароль
      firstName,
      lastName,
      age,
      gender,
    });

    await newUser.save();
    res.status(201).send("User registered successfully");
  } catch (error) {
    res.status(400).send("Error registering user: " + error.message);
  }
});

// Вход пользователя
router.post("/login", async (req, res) => {
  const { username, password, token } = req.body;

  if (!username || !password) {
    return res.status(400).send("Username and password are required");
  }

  // Найти пользователя по имени пользователя
  const user = await User.findOne({ username });
  if (!user) return res.status(400).send("Invalid username or password");

  // Проверка пароля
  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) return res.status(400).send("Invalid username or password");

  // Проверка двухфакторной аутентификации (если включена)
  if (user.twoFactorEnabled) {
    const isTokenValid = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: "base32",
      token,
    });
    if (!isTokenValid) return res.status(400).send("Invalid 2FA token");
  }

  res.status(200).send("Login successful");
});

// Настройка 2FA: генерация секрета и QR-кода
router.post("/2fa/setup", async (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).send("User ID is required");

  const user = await User.findById(userId);
  if (!user) return res.status(404).send("User not found");

  const secret = speakeasy.generateSecret({ name: "Portfolio Platform" });
  user.twoFactorSecret = secret.base32;
  user.twoFactorEnabled = true;
  await user.save();

  // Генерация QR-кода для сканирования
  qrcode.toDataURL(secret.otpauth_url, (err, data) => {
    if (err) return res.status(500).send("Error generating QR code");

    res.status(200).send({ qrCode: data, secret: secret.base32 });
  });
});

// Проверка кода 2FA
router.post("/2fa/verify", async (req, res) => {
  const { userId, token } = req.body;
  if (!userId || !token) return res.status(400).send("User ID and token are required");

  const user = await User.findById(userId);
  if (!user) return res.status(404).send("User not found");

  const verified = speakeasy.totp.verify({
    secret: user.twoFactorSecret,
    encoding: "base32",
    token,
  });

  if (verified) {
    res.status(200).send("2FA verified successfully");
  } else {
    res.status(400).send("Invalid 2FA code");
  }
});

// Отключение 2FA
router.post("/2fa/disable", async (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).send("User ID is required");

  const user = await User.findById(userId);
  if (!user) return res.status(404).send("User not found");

  user.twoFactorEnabled = false;
  user.twoFactorSecret = null;
  await user.save();
  res.status(200).send("2FA disabled successfully");
});

// Получение всех пользователей (для тестирования)
router.get("/users", async (req, res) => {
  try {
    const users = await User.find(); // Найти всех пользователей
    res.status(200).json(users); // Отправить список пользователей
  } catch (err) {
    res.status(500).send("Error fetching users: " + err.message);
  }
});

module.exports = router;
