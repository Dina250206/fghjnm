const mongoose = require("mongoose");

const PortfolioItemSchema = new mongoose.Schema({
  title: { type: String, required: true }, // Заголовок обязательный
  description: { type: String, required: true }, // Описание обязательное
  images: { type: [String], required: true }, // Массив строк (URLs изображений), обязательное поле
  createdAt: { type: Date, default: Date.now }, // Дата создания
  updatedAt: { type: Date, default: Date.now }, // Дата обновления
});

// Middleware для автоматического обновления поля updatedAt при изменении документа
PortfolioItemSchema.pre("save", function (next) {
  this.updatedAt = Date.now(); // Обновить поле updatedAt
  next();
});

// Middleware для обновления поля updatedAt при использовании методов update или findOneAndUpdate
PortfolioItemSchema.pre(["update", "findOneAndUpdate"], function (next) {
  this.set({ updatedAt: Date.now() }); // Обновить поле updatedAt
  next();
});

// Индексация по полю title для быстрого поиска
PortfolioItemSchema.index({ title: "text" }); // Создание текстового индекса для поиска по заголовкам

// Экспорт модели
module.exports = mongoose.model("PortfolioItem", PortfolioItemSchema);
