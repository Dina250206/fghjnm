const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const speakeasy = require('speakeasy');

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,  // Уникальность имени пользователя
    trim: true,  // Удаление лишних пробелов
  },
  password: {
    type: String,
    required: true,
    minlength: 8,  // Минимальная длина пароля
  },
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  age: {
    type: Number,
    required: true,
    min: 18,  // Минимальный возраст для регистрации
  },
  gender: {
    type: String,
    required: true,
    enum: ['male', 'female', 'other'],  // Ограничиваем список возможных значений
  },
  twoFactorEnabled: {
    type: Boolean,
    default: false,
  },
  twoFactorSecret: String,
});

// Добавление индекса на имя пользователя
UserSchema.index({ username: 1 }); // Индекс на поле username

// Хеширование пароля перед сохранением
UserSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Метод для проверки пароля
UserSchema.methods.isValidPassword = async function (password) {
  return await bcrypt.compare(password, this.password);
};

// Метод для включения двухфакторной аутентификации
UserSchema.methods.enableTwoFactor = function () {
  const secret = speakeasy.generateSecret({ name: this.username }); // Генерация секрета для пользователя
  this.twoFactorSecret = secret.base32; // Сохранение секрета в базе
  this.twoFactorEnabled = true;
};

// Метод для отключения двухфакторной аутентификации
UserSchema.methods.disableTwoFactor = function () {
  this.twoFactorEnabled = false;
  this.twoFactorSecret = null;
};

module.exports = mongoose.model("User", UserSchema);
