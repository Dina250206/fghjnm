require("dotenv").config(); // Для работы с переменными окружения
const express = require("express");
const mongoose = require("mongoose");
const authRoutes = require("./routes/auth"); // Маршруты для аутентификации
const portfolioRoutes = require("./routes/portfolio"); // Маршруты CRUD для портфолио
const cors = require("cors"); // Для настройки CORS (если нужно)
const { Authenticate, Authorize } = require("./middleware/Auth"); // Импортируем middleware для аутентификации и авторизации

const app = express();

// Middleware для обработки JSON и URL-encoded данных
app.use(express.json()); // Для обработки данных в формате JSON
app.use(express.urlencoded({ extended: true })); // Для обработки данных в формате URL-encoded (например, при отправке формы)

// Разрешение CORS (если нужно)
const corsOptions = {
  origin: 'http://localhost:4200', // Например, разрешаем доступ только с этого домена (или можно '*' для всех)
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'], // Разрешаем нужные заголовки
};
app.use(cors(corsOptions));

// Подключение маршрутов
app.use("/api/auth", authRoutes); // Маршруты аутентификации
app.use("/api/portfolio", Authenticate, Authorize(["admin", "editor"]), portfolioRoutes); // Маршруты CRUD для портфолио с защитой

// Подключение к MongoDB
mongoose
  .connect(process.env.MONGO_URI) // Получение строки подключения из переменной окружения
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.error("Could not connect to MongoDB...", err);
    process.exit(1); // Завершаем процесс с ошибкой, если не удается подключиться
  });

// Обработка ошибок для необработанных маршрутов
app.use((req, res, next) => {
  res.status(404).send({ error: "Route not found" });
});

// Обработка ошибок сервера
app.use((err, req, res, next) => {
  console.error(err.stack); // Логируем ошибку
  res.status(500).send({ error: "Something went wrong on the server" });
});

// Запуск сервера
const PORT = process.env.PORT || 3000; // Используем переменную окружения PORT или 3000 по умолчанию
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
