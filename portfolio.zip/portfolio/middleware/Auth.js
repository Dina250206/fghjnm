const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Middleware для проверки JWT и аутентификации пользователя
const Authenticate = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "");
  if (!token) {
    return res.status(401).send("Access denied. No token provided.");
  }

  try {
    // Декодирование токена с проверкой подписи
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Добавляем информацию о пользователе в запрос
    req.user = decoded;

    // Убедитесь, что роль присутствует в объекте пользователя
    if (!req.user.role) {
      return res.status(400).send("User role is not defined in token.");
    }

    next();
  } catch (err) {
    console.error("JWT verification error:", err); // Логирование ошибки для отладки
    res.status(400).send("Invalid token.");
  }
};

// Middleware для проверки роли пользователя (например, admin или editor)
const Authorize = (roles) => {
  return (req, res, next) => {
    // Проверка, существует ли роль пользователя
    if (!req.user || !req.user.role) {
      return res.status(400).send("User role is not defined.");
    }

    // Проверка, соответствует ли роль пользователя одной из разрешенных ролей
    if (!roles.includes(req.user.role)) {
      return res.status(403).send("Access denied. Insufficient role.");
    }
    next();
  };
};

module.exports = { Authenticate, Authorize };
